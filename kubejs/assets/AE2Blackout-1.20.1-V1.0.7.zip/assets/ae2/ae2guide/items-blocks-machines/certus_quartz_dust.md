---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Dust
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Certus Quartz Dust

<ItemImage id="certus_quartz_dust" scale="4" />

A <ItemLink id="certus_quartz_crystal" /> that has been crushed by an <ItemLink id="inscriber" />. Used in the production of
several AE2 materials and components.

## Recipe

<RecipeFor id="certus_quartz_dust" />
